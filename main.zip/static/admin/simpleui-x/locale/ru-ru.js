var Lanuages = {
    "Refresh": "Обновить",
    "Close current": "Закрыть эту вкладку",
    "Close other": "Закрыть другие вкладки",
    "Close all": "Закрыть все вкладки",
    "Open in a new page": "Окрыть на новой странице",
    "Change theme": "Сменить тему",
    "Default": "По умолчанию",
    "Servers": "Серверы",
    "Application information": "Информация о приложении",
    "Home page": "Домашняя страница",
    "Report issue": "Сообщить о проблеме",

    "Select": "Выбрать",
    "Selected": "Выбранные",


    "Purple": "Фиолетовый",
    "Gray": "Серый",
    "Dark green": "Тёмно зеленый",
    "Orange": "Оранжевый",
    "Black": "Черный",
    "Green": "Зеленый",
    "Light": "Светлый",

    "Number": "Число",
    "Theme name": "Название темы",
    "Action": "Действие",

    "ConfirmYes": "Да",
    "ConfirmNo": "Нет",
    "Tips": "Подсказки",
    "Are you sure you want them all closed": "Вы действительно хотите закрыть все вкладки?",

    "to": "в",
    "Quick navigation": "Быстрая навигация",
    "Go back": 'Назад',

    'Set font size': 'Размер шрифта',
    'Reset': 'Сбросить',
    'Are you sure you want to delete the selected?': 'Вы действительно хотите удалить выбранные элементы?',
    "Please select at least one option!": "Выберите хотя бы один вариант!",
    "Please enter your username or password!": "Введите ваш email и пароль"
}
